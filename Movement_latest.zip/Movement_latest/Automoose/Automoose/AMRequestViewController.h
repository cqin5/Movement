//
//  AMRequestViewController.h
//  Automoose
//
//  Created by LAVANYA  on 08/02/13.
//  Copyright (c) 2013 Srinivas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AMRequestViewController : UITableViewController
{
    NSMutableArray *dataArray;
}
@end
