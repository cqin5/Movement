//
//  AMPeopleViewer.h
//  Automoose
//
//  Created by Srinivas on 11/08/13.
//  Copyright (c) 2013 Srinivas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AMPeopleViewer : UIViewController
@property(nonatomic,strong)NSArray *peopleArray;
@property(nonatomic,strong)NSString *titleString;
@end
