//
//  AMPlaceObject.m
//  Automoose
//
//  Created by Srinivas on 2/1/13.
//  Copyright (c) 2013 Srinivas. All rights reserved.
//

#import "AMPlaceObject.h"

@implementation AMPlaceObject
@synthesize nameofPlace,address,photosArray,review,rating,latitude,longitude,placeIcon,placeId,iconUrl,isImageDownloaded,photoIdArray,mobileUrl;
@synthesize phoneNumber,categories;;
@end
