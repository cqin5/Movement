//
//  AMFacebookLoginController.h
//  Automoose
//
//  Created by Srinivas on 04/04/13.
//  Copyright (c) 2013 Srinivas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AMFacebookLoginController : PFLogInViewController<UITextFieldDelegate>

@end
