//
//  AMParticipantViewer.h
//  Automoose
//
//  Created by Srinivas on 12/15/12.
//  Copyright (c) 2012 Srinivas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AMParticipantViewer : UIViewController

@end
