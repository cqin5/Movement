//
//  AMEventsViewController.h
//  Automoose
//
//  Created by Lavanya on 03/03/13.
//  Copyright (c) 2013 Srinivas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AMEventsViewController : UITableViewController
@property(nonatomic,strong)NSArray *userEvents;
@end
