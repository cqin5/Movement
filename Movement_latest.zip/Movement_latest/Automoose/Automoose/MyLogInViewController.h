

@interface MyLogInViewController : PFLogInViewController<UITextFieldDelegate>

@end
