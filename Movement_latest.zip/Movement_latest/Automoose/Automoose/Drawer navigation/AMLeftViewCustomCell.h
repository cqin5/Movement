//
//  AMLeftViewCustomCell.h
//  Automoose
//
//  Created by Lavanya on 09/03/13.
//  Copyright (c) 2013 Srinivas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AMLeftViewCustomCell : UITableViewCell
//@property(nonatomic,strong)UIImageView *imageView;
//@property(nonatomic,strong)UILabel *label;
@end
