//
//  NowRingFiller.h
//  Automoose
//
//  Created by Srinivas on 17/04/13.
//  Copyright (c) 2013 Srinivas. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NowRingFiller : UIView

@end
