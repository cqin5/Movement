


@interface MySignUpViewController : PFSignUpViewController<UITextFieldDelegate>

@end
